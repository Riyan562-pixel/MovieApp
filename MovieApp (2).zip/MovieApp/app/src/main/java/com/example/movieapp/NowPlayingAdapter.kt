
package com.example.movieapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class NowPlayingAdapter(
    private val movieList: List<Movie>
) : RecyclerView.Adapter<NowPlayingAdapter.MovieViewHolder>() {

    class MovieViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val imgMovie: ImageView =
            itemView.findViewById(R.id.imgNowPlaying)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MovieViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_now_playing, parent, false)

        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: MovieViewHolder,
        position: Int
    ) {
        val movie = movieList[position]
        holder.imgMovie.setImageResource(movie.image)
    }

    override fun getItemCount(): Int {
        return movieList.size
    }
}
