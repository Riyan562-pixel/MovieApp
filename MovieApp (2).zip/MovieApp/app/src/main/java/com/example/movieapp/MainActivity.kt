
package com.example.movieapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Now Playing
        val viewPager = findViewById<ViewPager2>(
            R.id.viewPagerNowPlaying
        )

        val nowPlayingMovies = listOf(
            Movie("Avengers", R.drawable.movie1, "8.5"),
            Movie("Spider-Man", R.drawable.movie2, "9.0"),
            Movie("Batman", R.drawable.movie3, "8.7")
        )

        viewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        viewPager.isUserInputEnabled = true
        viewPager.adapter = NowPlayingAdapter(nowPlayingMovies)

        // Trending
        val rvTrending = findViewById<RecyclerView>(R.id.rvTrending)

        val trendingMovies = listOf(
            Movie("Avengers", R.drawable.movie1, "8.5"),
            Movie("Spider-Man", R.drawable.movie2, "9.0"),
            Movie("Batman", R.drawable.movie3, "8.7")
        )

        // Popular
        val rvPopular = findViewById<RecyclerView>(R.id.rvPopular)

        val popularMovies = listOf(
            Movie("Joker", R.drawable.movie4, "8.9"),
            Movie("Avatar", R.drawable.movie5, "8.8"),
            Movie("Iron Man", R.drawable.movie6, "8.4")
        )

        // Top Rated
        val rvTopRated = findViewById<RecyclerView>(R.id.rvTopRated)

        val topRatedMovies = listOf(
            Movie("Inception", R.drawable.movie7, "9.2"),
            Movie("Interstellar", R.drawable.movie8, "9.1"),
            Movie("Titanic", R.drawable.movie9, "8.8")
        )

        setupRecyclerView(rvTrending, trendingMovies)
        setupRecyclerView(rvPopular, popularMovies)
        setupRecyclerView(rvTopRated, topRatedMovies)
    }

    private fun setupRecyclerView(
        recyclerView: RecyclerView,
        movies: List<Movie>
    ) {
        recyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        recyclerView.adapter = MovieAdapter(movies)
    }
}
