
package com.example.movieapp

data class Movie(
    val title: String,
    val image: Int,
    val rating: String
)
